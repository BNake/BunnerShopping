
----------------------------------------------------------------------
E-Commerce Icons in Flat and Long Tailed Shadow Style by ONEXTRAPIXEL & Vecteezy
This freebie is brought to you by onextrapixel.com and vecteezy.com/
----------------------------------------------------------------------

TERMS OF USE:

This product may be used free of charge for personal and/or commercial purposes. 

However, you may not sell, modify or distribute any of the files on any website, torrent or by any other means whatsoever (whether online or offline) or claim them as your own.

If you'd like to share this file with others, please direct them to our original release where they can download their copy.

We also welcome and greatly appreciate any form of credits back to our product.

Thank you for supporting our website and we hope you enjoy our product. 


ONEXTRAPIXEL
_________________________
website: www.onextrapixel.com
email:   hello@onextrapixel.com

